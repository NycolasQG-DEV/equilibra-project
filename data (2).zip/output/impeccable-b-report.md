# Assessment B — auditoria técnica independente

Data: 21/10/2026. Escopo: implementação web Equilibra, leitura de código e evidências da própria avaliação B. Nenhum relatório ou captura A foi consultado. Nenhuma interface ou dado real foi alterado.

## Veredito de integridade

**Passa quanto à coerência do produto; não passa como pronto para liberação.** A aplicação contém fluxos específicos de pessoas, grupos, ciclos, privacidade coletiva e ações. Alertas estéticos do detector não demonstram falta de integridade. Existem lacunas verificáveis de teclado, contraste e recuperação de erros.

## Notas provisórias

| Dimensão | Nota /4 | Evidência principal |
|---|---:|---|
| Acessibilidade | 2 | Listbox sem operação por teclado; contrastes insuficientes |
| Performance | 3 | Assets locais e scripts defer; cinco transições de width, sem medição de frames |
| Responsividade | 3 | Captura B em 390 px com lista em cartões; alvos pequenos |
| Theming | 1 | Cores literais recorrentes, sem tokens de cores compartilhados nas folhas inspecionadas |
| Integridade | 3 | Sistema coerente; erro de carregamento confundido com falta de autenticação |
| Total | 12/20 | Aceitável, com trabalho significativo antes da liberação |

Notas representam amostra limitada, não certificação WCAG, performance ou compatibilidade. Ausência de modo escuro não é defeito de produto por si só; nota de theming mede preparação técnica.

## Achados priorizados

### [P1] Filtro de grupo não permite selecionar opções com teclado

Fonte: `public/js/app.js:102-129`, `1751-1797`. O listbox tem tabindex=-1 e opções div sem tabindex. O clique abre o menu sem mover o foco. O único tratamento de teclado do dropdown cobre Escape; não há ArrowDown/ArrowUp, Enter/Space ou roving tabindex. Impacto: usuário de teclado não consegue executar a seleção equivalente ao clique. WCAG 2.1.1. Recomendação: select nativo ou implementação completa do padrão listbox. Comando: `$impeccable harden`.

Estado da evidência: confirmado por código e reproduzido na rodada curta de retomada. Enter abre o menu; ArrowDown mantém foco em filter-dropdown-trigger e seleção em Todos os grupos. Enter seguinte apenas fecha o menu.

### [P1] Contraste insuficiente em textos funcionais

Fontes: `public/css/styles.css:28`; `output/impeccable-b-console.log`. Cabeçalhos da tabela usam #9ba9a0 sobre #fbfcfa, aproximadamente 2,4:1; sidebar apresenta texto #9ba7a0 sobre branco, aproximadamente 2,5:1. Detector runtime B também registrou 3,9:1 e 4,4:1. Impacto: leitura difícil para baixa visão; cabeçalhos pequenos exigem 4,5:1 em WCAG 1.4.3. Ajustar cores funcionais e repetir aferição por estado. Comando: `$impeccable harden`.

Estado: valores registrados em runtime anterior B e cor de cabeçalhos confirmada no CSS. Não foram medidos todos os estados nem telas.

### [P1] Falha de qualquer dependência inicial devolve usuário ao login

Fontes: `public/js/app.js:47-56`, `1897-1913`. `load()` usa Promise.all com sete endpoints, incluindo `/api/management/workspace`. O catch externo apaga state.account e renderiza login para qualquer erro, inclusive 500, sem distinguir sessão inválida de falha temporária. Impacto: endpoint secundário indisponível bloqueia workspace e induz usuário a refazer login. Preservar autenticação, isolar dependências e fornecer erro recuperável/repetir carregamento. Comando: `$impeccable harden`.

Estado: comportamento identificado por código e reproduzido na rodada curta. Interceptação somente na sessão B devolveu 500 sintético em `/api/management/workspace` antes do reload. Resultado: hash #login, heading Bem-vindo de volta, toast vazio. Ao remover interceptação e recarregar, autenticação servidor ainda válida devolveu #geral. Console da reprodução: `output/impeccable-b-resume-console.log`. Não houve falha real provocada no servidor.

### [P2] Modal não restaura foco ao botão que o abriu

Fontes: `public/js/app.js:490-503`, `1583`. Existe foco inicial e ciclo Tab/Shift+Tab; fechamento apenas remove #modal. Nenhuma referência ao elemento invocador é armazenada para restauração. Impacto: teclado perde posição de trabalho ao fechar diálogo. Recomendação: guardar invocador, restaurar foco se conectado, centralizar fechamento. Referência: padrão ARIA Dialog e ordem de foco WCAG 2.4.3. Comando: `$impeccable harden`.

Estado: verificado por código e navegador. Abrir Cadastrar pessoa e fechar pelo botão Fechar resulta em document.activeElement=BODY, sem retorno ao invocador.

### [P2] Ações pequenas na experiência móvel

Fonte: `public/css/styles.css:28`, `30`; `output/playwright/b-mobile.png` (390 x 844). Editar/Excluir usam fonte 12 px e padding 5 px; medição em 390 px confirmou primeiro .table-action com 43,14 x 26 px. Botão de fechar não possui mínimo explícito de alvo. Impacto: menor precisão de toque. Recomenda-se área mínima de 44 x 44 px sem ampliar necessariamente o ícone. 44 px é critério de conforto desta auditoria, não prova automática de violação WCAG AA 2.5.8, que exige considerar 24 px e exceções de espaçamento. Comando: `$impeccable adapt`.

### [P2] Cores sem tokens compartilhados e redução global de movimento

Fontes: `public/css/styles.css:1`, `28`, `30`, `80`. Cores se repetem como literais; regra reduced-motion reduz globalmente animações/transições para .01ms. Impacto: manutenção de contraste exige alterações distribuídas; alternativa de movimento não distingue feedback útil de decoração. Criar tokens sem mudar identidade e oferecer redução direcionada. Comandos: `$impeccable extract` e `$impeccable animate`.

## Detector: contagens e triagem

Arquivo JSON íntegro reutilizado: `output/impeccable-detector.json`. Não houve nova execução. Total: **9 avisos**, categorias **quality=5**, **slop=4**. Nenhum equivale automaticamente a defeito.

| Regra | Contagem | Triagem |
|---|---:|---|
| layout-transition | 5 | Width em barras de progresso, styles.css:288,350,390,676,755. Potencial custo de layout; não há evidência de jank. Não elevado a P1/P2 sem medição. |
| side-tab | 1 | styles.css:32, borda de nota de privacidade. Uso semântico contextual; não é defeito confirmado. |
| overused-font | 1 | styles.css:1, Inter. Preferência estética, não defeito técnico. |
| dark-glow | 1 | index.html:0, localização imprecisa; documento claro. Não confirmado; descartar como achado técnico. |
| bounce-easing | 1 | vendor/fontawesome/css/all.min.css:6. Código vendor; presença não prova uso da animação. Não alterar vendor por este aviso. |

Runtime B: contraste e texto funcional de 10/10,5 px merecem contexto. Kicker, Inter, travessões, borda+sombra e tabela sem padding externo não são defeitos automaticamente. Padding existe nas células; não adicionar inset à tabela apenas para silenciar cramped-padding. Repetições no log são leituras de telas distintas, não contagem de defeitos únicos.

## Pontos positivos

- HTML declara pt-BR, viewport e scripts defer; assets principais são locais (`public/index.html:2-17`).
- Navegação possui landmark nomeado; botões nativos e estados ativos estão presentes (`public/js/app.js:174`).
- Modal tem role=dialog, aria-modal, nome e contenção Tab (`490-503`).
- Toast tem role=status e aria-live (`public/index.html:21`).
- Captura B móvel mostra cartões legíveis sem corte lateral visível; adaptação é real na tela Pessoas. Não prova todas as rotas.

## Evidências, navegador e limites

Capturas B preservadas: `output/playwright/b-desktop.png`, `b-mobile.png`; console: `output/impeccable-b-console.log`. A captura móvel foi reinspecionada nesta retomada. Nenhuma evidência A foi lida.

Na retomada, review-b anterior já não estava disponível e QA3107 inicialmente recusou conexão. Após o pai restabelecer QA, uma sessão CLI isolada review-b foi aberta sem --headed. A rodada curta confirmou teclado, foco, medidas em 390 px e 500 inicial. Sessão review-b foi fechada explicitamente ao final. Nenhuma aba do usuário em localhost:3000 foi usada. Uma tentativa anterior de IAB em background criou somente página de erro; aquisição para fechar foi bloqueada por política da URL data e tentativa posterior informou que visibility não é suportada em subagente. Essa aba temporária não foi marcada para persistência e depende da limpeza automática do turno.

Overlay anterior: `.impeccable/live/server.json` ainda cita PID25716/8400, porém consulta Win32_Process não encontrou esse processo. Registro é residual; nenhum processo foi encerrado. Main3000 e QA3107 não foram parados por B.

Checks de teclado, foco e 500 inicial têm confirmação dinâmica. Em Pessoas, viewport 390 e documentElement.scrollWidth 390 com dropdown fechado; ao abrir dropdown, scrollWidth 398: transbordamento horizontal de 8 px neste estado, P2 agrupado à adaptação móvel. Responsividade não foi validada em todas as rotas. Sem zoom 200%, leitor de tela, dispositivos reais, Lighthouse, tempos de rede, análise completa de bundles ou métricas de frames. Não há comprovação de lazy loading faltante nem layout thrashing por loops. Dados reais permaneceram intocados.

## Próximas ações

1. `$impeccable harden`: corrigir teclado do filtro, contraste, foco e tratamento de falhas sem apagar sessão válida.
2. `$impeccable adapt`: aumentar alvos móveis e verificar telas a 390 px e zoom 200%.
3. `$impeccable extract` / `$impeccable animate`: tokens compartilhados e redução de movimento direcionada.
4. `$impeccable audit`: repetir somente checks afetados após correções, incluindo 500 de workspace inicial.
5. `$impeccable polish`: confirmação final depois das correções funcionais.

Comandos podem ser executados individualmente ou em conjunto, na ordem escolhida pelo usuário. Esta avaliação apenas documenta; não aplica correções.
