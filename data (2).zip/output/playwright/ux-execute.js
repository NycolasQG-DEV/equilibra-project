async page => {
  await page.getByRole('button',{name:'Adicionar evidência',exact:true}).first().click();
  await page.getByRole('textbox',{name:'O que foi realizado? Registre evidência sem dados pessoais.',exact:true}).fill('Redistribuição de tarefas registrada com a equipe.');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'Registrar implementação',exact:true}).click();
  await page.getByRole('button',{name:'Registrar verificação',exact:true}).waitFor();
  await page.getByRole('button',{name:'Registrar verificação',exact:true}).click();
}
