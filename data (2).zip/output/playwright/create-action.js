async page => {
  await page.getByRole('textbox', {name:'Título', exact:true}).fill('Redistribuir atividades');
  await page.getByRole('textbox', {name:'Medida a implementar', exact:true}).fill('Rever distribuição e prioridades com a equipe.');
  await page.getByRole('textbox', {name:'Responsável', exact:true}).fill('Gestão de operações');
  await page.getByRole('textbox', {name:'Prazo de execução', exact:true}).fill('2026-01-01');
  await page.getByRole('textbox', {name:'Data de revisão', exact:true}).fill('2026-02-01');
  await page.getByRole('textbox', {name:'Como verificar se funcionou?', exact:true}).fill('Revisar horas extras e percepção no próximo ciclo.');
  await page.getByRole('button', {name:'Salvar', exact:true}).click();
  await page.getByRole('button', {name:'Ações', exact:true}).click();
  await page.getByRole('heading', {name:'Redistribuir atividades', exact:true}).waitFor();
}
