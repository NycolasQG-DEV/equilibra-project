async page => {
  await page.getByRole('combobox', {name:'Estado',exact:true}).selectOption('in_progress');
  await page.getByRole('button', {name:'Salvar',exact:true}).click();
  await page.getByRole('button', {name:'Abrir ação',exact:true}).click();
  await page.getByRole('combobox', {name:'Estado',exact:true}).selectOption('implemented');
  await page.getByRole('button', {name:'Salvar',exact:true}).click();
  await page.getByRole('button', {name:'Abrir ação',exact:true}).click();
  await page.getByRole('combobox', {name:'Estado',exact:true}).selectOption('effective');
  await page.getByRole('textbox', {name:'Verificação de eficácia e justificativa',exact:true}).fill('Revisão com registros operacionais confirmou redução da sobrecarga percebida.');
  await page.getByRole('button', {name:'Salvar',exact:true}).click();
  await page.getByText('Eficaz', {exact:true}).waitFor();
  await page.screenshot({path:'output/playwright/actions-desktop.png',fullPage:true});
}
