async page => {
  await page.setViewportSize({width:1440,height:1000});
  await page.getByRole('textbox',{name:'Título do achado',exact:true}).fill('Revisar distribuição das demandas');
  await page.getByRole('textbox',{name:'Contexto e condições de trabalho investigadas',exact:true}).fill('Equipe revisou volume, jornadas e distribuição das atividades.');
  await page.getByRole('textbox',{name:'Decisão e justificativa',exact:true}).fill('Reorganizar prioridades com a liderança operacional.');
  await page.getByRole('combobox',{name:'Estado da avaliação',exact:true}).selectOption('evaluated');
  await page.getByRole('combobox',{name:'Prioridade definida pelo responsável',exact:true}).selectOption('medium');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'Planejar ação',exact:true}).click();
  await page.getByRole('textbox',{name:'Título',exact:true}).fill('Reorganizar prioridades da operação');
  await page.getByRole('textbox',{name:'Medida a implementar',exact:true}).fill('Revisar capacidade e distribuir tarefas por prioridade.');
  await page.getByRole('textbox',{name:'Responsável',exact:true}).fill('Coordenação operacional');
  await page.getByRole('textbox',{name:'Prazo de execução',exact:true}).fill('2026-01-01');
  await page.getByRole('textbox',{name:'Data de revisão',exact:true}).fill('2026-02-01');
  await page.getByRole('textbox',{name:'Como verificar se funcionou?',exact:true}).fill('Comparar registros de horas extras e revisar percepção da equipe.');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('heading',{name:'Reorganizar prioridades da operação',exact:true}).waitFor();
  if (!page.url().includes('#acoes/')) throw new Error('Criação não abriu a página da ação');
  if (await page.getByRole('navigation',{name:'Navegação principal'}).getByRole('button',{name:'Assinatura',exact:true}).count()) throw new Error('Assinatura ainda está na navegação');
  await page.screenshot({path:'output/playwright/ux-action-desktop.png',fullPage:true});
  await page.getByRole('button',{name:'Iniciar execução',exact:true}).click();
  await page.getByRole('button',{name:'Adicionar evidência',exact:true}).last().waitFor();
}
