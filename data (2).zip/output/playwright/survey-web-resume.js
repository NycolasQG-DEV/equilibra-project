async page => {
 const dialog=page.getByRole('dialog');
 await dialog.getByRole('link',{name:'Abrir formulário web',exact:true}).waitFor();
 const fullUrl=await dialog.locator('#single-survey-url').inputValue();
 const participant=await page.context().newPage();
 await participant.goto(fullUrl);
 await participant.getByRole('button',{name:'Enviar resposta',exact:true}).waitFor();
 if(await participant.locator('fieldset').count()!==35) throw Error('HSE response fields mismatch');
 await participant.getByRole('button',{name:'Enviar resposta',exact:true}).click();
 if(await participant.getByRole('heading',{name:'Resposta enviada',exact:true}).count()) throw Error('Incomplete form submitted');
 for(const field of await participant.locator('fieldset').all()) await field.getByRole('radio').nth(2).check();
 if(await participant.evaluate(()=>document.documentElement.scrollWidth>innerWidth)) throw Error('Form overflow');
 await participant.screenshot({path:'output/playwright/survey-hse-form.png',fullPage:true});
 await participant.getByRole('button',{name:'Enviar resposta',exact:true}).click();
 await participant.getByRole('heading',{name:'Resposta enviada',exact:true}).waitFor();
 const surveyId=fullUrl.split('/').pop();
 for(let i=0;i<9;i++) {
  const answers=Object.fromEntries(Array.from({length:35},(_,i)=>[`hse_${i+1}`,3]));
  const r=await page.request.post(`http://127.0.0.1:3107/api/respond/${surveyId}`,{data:{answers},headers:{Cookie:''}});
  if(r.status()!==201) throw Error('Synthetic answers rejected');
 }
 await participant.reload();
 await participant.getByRole('heading',{name:'Resposta já enviada',exact:true}).waitFor();
 await participant.close();
 await dialog.getByRole('button',{name:'Concluir',exact:true}).click();
 await page.reload();
 const refreshed=page.locator('article').filter({has:page.getByRole('heading',{name:'Pesquisa de Percepção do Trabalho',exact:true})});
 await refreshed.getByRole('button',{name:'Encerrar coleta',exact:true}).click();
}
