async page => {
  await page.evaluate(() => scrollTo(0,0));
  await page.screenshot({path:'output/playwright/actions-mobile.png',fullPage:true});
  const width = await page.evaluate(() => ({viewport:innerWidth,content:document.documentElement.scrollWidth}));
  if (width.content > width.viewport) throw new Error('Overflow: '+JSON.stringify(width));
  await page.getByRole('button',{name:'Abrir menu',exact:true}).click();
  await page.getByRole('button',{name:'Assinatura',exact:true}).click();
  await page.getByRole('heading',{name:'Planos para sua operação',exact:true}).waitFor();
  await page.evaluate(() => scrollTo(0,0));
  await page.screenshot({path:'output/playwright/billing-mobile.png',fullPage:true});
  const billingWidth = await page.evaluate(() => ({viewport:innerWidth,content:document.documentElement.scrollWidth}));
  if (billingWidth.content > billingWidth.viewport) throw new Error('Overflow de assinatura: '+JSON.stringify(billingWidth));
}
