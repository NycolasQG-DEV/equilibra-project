async page => {
 const errors=[]; page.on('pageerror',e=>errors.push(e.message));
 await page.setViewportSize({width:1440,height:1000});
 await page.locator('.dashboard-chart canvas').waitFor();
 console.log('overview',await page.evaluate(()=>({charts:Object.keys(Chart.instances).length, font:document.fonts.check('18px "Font Awesome 7 Free"')})));
 await page.screenshot({path:'output/playwright/chart-overview.png',fullPage:true});
 await page.evaluate(()=>location.hash='resultados');
 await page.getByRole('link',{name:'Abrir ciclo'}).first().click();
 await page.locator('.dashboard-chart canvas').waitFor();
 await page.getByRole('button',{name:'Comparar ciclos',exact:true}).click();
 await page.locator('#comparison-result canvas').waitFor();
 console.log('comparison',await page.evaluate(()=>Object.values(Chart.instances).map(c=>({labels:c.data.labels.length,datasets:c.data.datasets.length})))) ;
 await page.setViewportSize({width:390,height:844});
 await page.screenshot({path:'output/playwright/chart-mobile.png',fullPage:true});
 console.log('mobile',await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,charts:Object.keys(Chart.instances).length})));
 await page.evaluate(()=>location.hash='resultados/documentos');
 await page.getByRole('heading',{name:'Relatórios e histórico',exact:true}).waitFor();
 console.log('cleanup',await page.evaluate(()=>Object.keys(Chart.instances).length),'errors',errors);
}
