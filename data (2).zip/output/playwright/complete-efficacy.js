async page => {
  await page.getByRole('button',{name:'Adicionar evidência',exact:true}).click();
  await page.getByRole('textbox',{name:'O que foi realizado? Registre evidência sem dados pessoais.',exact:true}).fill('Redistribuição registrada em ata da equipe.');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'Abrir ação',exact:true}).click();
  await page.getByRole('combobox',{name:'Estado',exact:true}).selectOption('in_progress');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'Abrir ação',exact:true}).click();
  await page.getByRole('combobox',{name:'Estado',exact:true}).selectOption('implemented');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'Abrir ação',exact:true}).click();
  await page.getByRole('combobox',{name:'Estado',exact:true}).selectOption('effective');
  await page.getByRole('textbox',{name:'Verificação de eficácia e justificativa',exact:true}).fill('Revisão dos registros operacionais e da percepção confirmou resultado favorável.');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByText('Eficaz',{exact:true}).waitFor();
  await page.screenshot({path:'output/playwright/actions-desktop.png',fullPage:true});
}
