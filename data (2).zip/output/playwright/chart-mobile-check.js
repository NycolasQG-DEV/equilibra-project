async page => {
 await page.evaluate(()=>location.hash='resultados');
 await page.getByRole('link',{name:'Abrir ciclo'}).first().click();
 await page.locator('.dashboard-chart canvas').waitFor();
 await page.getByRole('button',{name:'Comparar ciclos',exact:true}).click();
 await page.locator('#comparison-result canvas').waitFor();
 await page.reload();
 await page.locator('.dashboard-chart canvas').waitFor();
 await page.getByRole('button',{name:'Comparar ciclos',exact:true}).click();
 await page.locator('#comparison-result canvas').waitFor();
 await page.waitForFunction(()=>Object.keys(Chart.instances).length===2);
 if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)) throw Error('Mobile overflow');
 await page.screenshot({path:'output/playwright/chart-mobile.png',fullPage:true});
 await page.evaluate(()=>location.hash='resultados/documentos');
 await page.waitForFunction(()=>Object.keys(Chart.instances).length===0);
}
