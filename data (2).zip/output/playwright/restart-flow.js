async page => {
  await page.getByRole('textbox',{name:'E-mail',exact:true}).fill('qa@example.test');
  await page.getByRole('textbox',{name:'Senha',exact:true}).fill('senha-teste-123');
  await page.getByRole('button',{name:'Entrar',exact:true}).click();
  await page.getByRole('button',{name:'Resultados',exact:true}).waitFor();
  await page.getByRole('button',{name:'Resultados',exact:true}).click();
  await page.getByRole('button',{name:'Avaliar achado',exact:true}).nth(1).click();
  await page.getByRole('textbox',{name:'Título do achado',exact:true}).fill('Investigar carga de trabalho');
  await page.getByRole('textbox',{name:'Contexto e condições de trabalho investigadas',exact:true}).fill('Revisão de jornadas e distribuição das atividades.');
  await page.getByRole('textbox',{name:'Decisão e justificativa',exact:true}).fill('Reorganizar as prioridades da equipe.');
  await page.getByRole('combobox',{name:'Estado da avaliação',exact:true}).selectOption('evaluated');
  await page.getByRole('combobox',{name:'Prioridade definida pelo responsável',exact:true}).selectOption('high');
  await page.getByRole('button',{name:'Salvar',exact:true}).click();
  await page.getByRole('dialog').waitFor({state:'hidden'});
  await page.getByRole('button',{name:'Planejar ação',exact:true}).click();
}
