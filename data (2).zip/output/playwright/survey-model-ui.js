async page => {
 await page.getByRole('button',{name:'Pesquisas',exact:true}).click();
 await page.getByRole('button',{name:'Modelos e metodologia',exact:true}).click();
 await page.getByRole('heading',{name:'Modelos e metodologia',exact:true}).waitFor();
 if(await page.getByRole('dialog').getByText('COPSOQ II / III',{exact:true}).count()!==1) throw Error('Catalog missing');
 await page.getByRole('button',{name:'Fechar catálogo',exact:true}).click();
 await page.getByRole('button',{name:'Nova pesquisa',exact:false}).first().click();
 await page.getByRole('button',{name:'Continuar: Opções de Pesquisa',exact:false}).click();
 await page.getByRole('button',{name:'HSE — indicador de estresse',exact:false}).click();
 if(await page.locator('.wizard-questions-list li').count()!==35) throw Error('Preview mismatch');
 await page.setViewportSize({width:390,height:844});
 if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth)) throw Error('Wizard overflow');
 await page.screenshot({path:'output/playwright/survey-model-selection.png',fullPage:true});
 await page.getByRole('button',{name:'Continuar: Prazos e Lançamento',exact:false}).click();
}

