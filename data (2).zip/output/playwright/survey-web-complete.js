async page => {
 await page.getByRole('button',{name:'Concluir e Criar Pesquisa',exact:false}).click();
 const title='Pesquisa de Percepção do Trabalho';
 const card=page.locator('article').filter({has:page.getByRole('heading',{name:title,exact:true})});
 await card.getByRole('button',{name:'Iniciar coleta',exact:false}).click();
 const opening=page.waitForResponse(r=>r.url().includes('/open')&&r.request().method()==='POST');
 await page.getByRole('button',{name:'Sim, iniciar coleta',exact:false}).click();
 const opened=await (await opening).json();
 const dialog=page.getByRole('dialog');
 if(await dialog.getByRole('link',{name:'Abrir formulário web',exact:true}).count()!==1) throw Error('Web sharing missing');
 if(await dialog.getByText('Enviar no WhatsApp',{exact:true}).count()) throw Error('WhatsApp remains');
 const participant=await page.context().newPage();
 await participant.goto(`http://127.0.0.1:3107/responder/${opened.links[0].token}`);
 await participant.getByRole('button',{name:'Enviar resposta',exact:true}).waitFor();
 if(await participant.locator('fieldset').count()!==35) throw Error('HSE response fields mismatch');
 await participant.getByRole('button',{name:'Enviar resposta',exact:true}).click();
 if(await participant.getByRole('heading',{name:'Resposta enviada',exact:true}).count()) throw Error('Incomplete form submitted');
 for(const field of await participant.locator('fieldset').all()) await field.getByRole('radio').nth(2).check();
 if(await participant.evaluate(()=>document.documentElement.scrollWidth>innerWidth)) throw Error('Form overflow');
 await participant.screenshot({path:'output/playwright/survey-hse-form.png',fullPage:true});
 await participant.getByRole('button',{name:'Enviar resposta',exact:true}).click();
 await participant.getByRole('heading',{name:'Resposta enviada',exact:true}).waitFor();
 for(const link of opened.links.slice(1)) {
  const answers=Object.fromEntries(Array.from({length:35},(_,i)=>[`hse_${i+1}`,3]));
  const r=await page.request.post(`http://127.0.0.1:3107/api/respond/${link.token}`,{data:{answers}});
  if(r.status()!==201) throw Error('Synthetic answers rejected');
 }
 await participant.close();
 await dialog.getByRole('button',{name:'Concluir',exact:true}).click();
 await page.reload();
 const refreshed=page.locator('article').filter({has:page.getByRole('heading',{name:title,exact:true})});
 await refreshed.getByRole('button',{name:'Encerrar coleta',exact:true}).click();
}
