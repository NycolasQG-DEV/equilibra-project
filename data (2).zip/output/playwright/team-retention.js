async page => {
  await page.getByRole('textbox',{name:'E-mail do colaborador',exact:true}).fill('colaborador@example.test');
  await page.getByRole('combobox',{name:'Permissão',exact:true}).selectOption('viewer');
  await page.getByRole('button',{name:'Gerar convite',exact:true}).click();
  await page.getByRole('textbox',{name:'Código do convite (exibido somente agora)',exact:true}).waitFor();
  await page.getByRole('button',{name:'Fechar',exact:true}).click();
  await page.getByRole('button',{name:'Dados e retenção',exact:true}).click();
  await page.getByRole('heading',{name:'Dados e retenção',exact:true}).waitFor();
  const dimensions = await page.evaluate(() => ({viewport:innerWidth, content:document.documentElement.scrollWidth}));
  if (dimensions.content > dimensions.viewport) throw new Error('Overflow na retenção');
  await page.getByRole('button',{name:'Fechar',exact:true}).click();
  await page.getByRole('button',{name:'Alterar senha',exact:true}).click();
  await page.getByRole('textbox',{name:'Senha atual',exact:true}).waitFor();
  await page.getByRole('button',{name:'Fechar',exact:true}).click();
}
