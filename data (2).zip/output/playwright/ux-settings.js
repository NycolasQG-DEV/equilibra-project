async page => {
  await page.screenshot({path:'output/playwright/ux-billing-desktop.png',fullPage:true});
  await page.getByRole('link',{name:'Privacidade e dados',exact:true}).click();
  await page.getByRole('heading',{name:'Retenção de respostas',exact:true}).waitFor();
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.setViewportSize({width:390,height:844});
  await page.evaluate(() => scrollTo(0,0));
  await page.screenshot({path:'output/playwright/ux-privacy-mobile.png',fullPage:true});
  let size = await page.evaluate(() => ({w:innerWidth,c:document.documentElement.scrollWidth}));
  if (size.c > size.w) throw new Error('Overflow em configurações: '+JSON.stringify(size));
  await page.goto('http://127.0.0.1:3107/#relatorios');
  await page.getByRole('heading',{name:'Relatórios e histórico',exact:true}).waitFor();
  if (!page.url().includes('#resultados/documentos')) throw new Error('Link antigo de relatórios não foi redirecionado');
  await page.screenshot({path:'output/playwright/ux-documents-mobile.png',fullPage:true});
  size = await page.evaluate(() => ({w:innerWidth,c:document.documentElement.scrollWidth}));
  if (size.c > size.w) throw new Error('Overflow em relatórios');
  await page.goto('http://127.0.0.1:3107/#assinatura');
  await page.getByRole('heading',{name:'Seu plano',exact:true}).waitFor();
  if (!page.url().includes('#configuracoes/plano')) throw new Error('Link antigo de assinatura não foi redirecionado');
  await page.screenshot({path:'output/playwright/ux-billing-mobile.png',fullPage:true});
  size = await page.evaluate(() => ({w:innerWidth,c:document.documentElement.scrollWidth}));
  if (size.c > size.w) throw new Error('Overflow em cobrança');
}
