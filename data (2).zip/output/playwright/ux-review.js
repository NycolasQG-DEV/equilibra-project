async page => {
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('combobox',{name:'Resultado da verificação',exact:true}).selectOption('effective');
  await dialog.getByRole('textbox',{name:'O que comprova o resultado?',exact:true}).fill('Registros operacionais e revisão da equipe confirmam a melhoria esperada.');
  await dialog.getByRole('button',{name:'Registrar verificação',exact:true}).click();
  await dialog.waitFor({state:'hidden'});
  await page.getByRole('heading',{name:'Verificação registrada',exact:true}).waitFor();
  await page.getByRole('button',{name:'Configurações',exact:true}).click();
}
