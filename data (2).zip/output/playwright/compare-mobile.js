async page => {
  await page.getByRole('button',{name:'Resultados',exact:true}).click();
  await page.getByRole('combobox',{name:'Ciclo de referência',exact:true}).selectOption({label:'Linha de base · Janeiro 2026'});
  await page.getByRole('combobox',{name:'Ciclo atual',exact:true}).selectOption({label:'Pulso de fevereiro · Fevereiro 2026'});
  await page.getByRole('button',{name:'Comparar',exact:true}).click();
  await page.getByText('Diferenças de médias são descritivas; não demonstram causalidade ou significância estatística.',{exact:true}).waitFor();
  await page.screenshot({path:'output/playwright/results-desktop.png',fullPage:true});
  await page.setViewportSize({width:390,height:844});
  const dimensions = await page.evaluate(() => ({width:innerWidth, content:document.documentElement.scrollWidth}));
  if (dimensions.content > dimensions.width) throw new Error('Overflow em resultados: '+JSON.stringify(dimensions));
  await page.screenshot({path:'output/playwright/results-mobile.png',fullPage:true});
}
