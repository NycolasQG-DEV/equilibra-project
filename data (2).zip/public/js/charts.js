window.DashboardCharts = (() => {
  const charts = new Map();
  const escape = (value) => String(value).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function markup(rows, comparison = false) {
    return `<div class="dashboard-chart" data-chart="${escape(JSON.stringify({rows, comparison}))}"><canvas role="img" aria-label="${comparison ? 'Comparação descritiva entre ciclos' : 'Percepção por fator'}: escala de 1 a 5. Valores numéricos disponíveis abaixo."></canvas></div>`;
  }
  function mount() {
    for (const [canvas, chart] of charts) if (!canvas.isConnected) { chart.destroy(); charts.delete(canvas); }
    if (!window.Chart) return;
    document.querySelectorAll('[data-chart]').forEach((container) => {
      const canvas = container.querySelector('canvas');
      if (charts.has(canvas)) return;
      const { rows, comparison } = JSON.parse(container.dataset.chart);
      if (!rows.length) return;
      container.style.height = `${Math.max(280, rows.length * (comparison ? 58 : 42))}px`;
      const currentColors = rows.map(r => {
        if (r.average < 2.5) return '#b91c1c'; // Atenção Crítica (Abaixo de 2.5)
        if (r.average < 3.2) return '#b45309'; // Atenção Moderada (2.5 a 3.19)
        if (r.average >= 4.0) return '#432874'; // Ponto Forte / Excelente (Roxo Royal Primário)
        return '#7048b6'; // Percepção Favorável (Violeta Acento)
      });
      const datasets = [{
        label: comparison ? 'Ciclo atual' : 'Percepção média',
        data: rows.map(r => r.average),
        backgroundColor: comparison ? '#432874' : currentColors,
        borderRadius: 6,
        maxBarThickness: 22
      }];
      if (comparison) {
        datasets.unshift({
          label: 'Ciclo de referência',
          data: rows.map(r => r.previous),
          backgroundColor: '#cfc6dc',
          borderRadius: 6,
          maxBarThickness: 22
        });
      }
      charts.set(canvas, new Chart(canvas, {
        type: 'bar',
        data: { labels: rows.map(r => r.label), datasets },
        options: {
          indexAxis: 'y',
          responsive: true,
          maintainAspectRatio: false,
          animation: matchMedia('(prefers-reduced-motion: reduce)').matches ? false : { duration: 250 },
          plugins: {
            legend: {
              display: comparison,
              position: 'bottom',
              labels: { boxWidth: 12, font: { family: "'Plus Jakarta Sans', system-ui, sans-serif", size: 12, weight: 600 }, color: '#524765' }
            },
            tooltip: {
              backgroundColor: '#1c142b',
              titleFont: { family: "'Plus Jakarta Sans', system-ui, sans-serif", size: 13, weight: 700 },
              bodyFont: { family: "'Plus Jakarta Sans', system-ui, sans-serif", size: 12 },
              padding: 10,
              cornerRadius: 8,
              callbacks: {
                label: c => {
                  const val = Number(c.raw);
                  let status = '';
                  if (val < 2.5) status = ' (Atenção Crítica)';
                  else if (val < 3.2) status = ' (Atenção Moderada)';
                  else if (val >= 4.0) status = ' (Favorável)';
                  return `${c.dataset.label}: ${val.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / 5.00${status}`;
                }
              }
            }
          },
          scales: {
            x: {
              min: 1,
              max: 5,
              ticks: { stepSize: 1, color: '#827796', font: { family: "'Plus Jakarta Sans', system-ui, sans-serif", size: 11 } },
              title: { display: true, text: 'Escala de percepção (1 = desfavorável a 5 = favorável)', color: '#827796', font: { size: 11, weight: 600 } },
              grid: { color: '#eee8f4' }
            },
            y: {
              grid: { display: false },
              ticks: { color: '#1c142b', font: { family: "'Plus Jakarta Sans', system-ui, sans-serif", size: 12, weight: 600 } }
            }
          }
        }
      }));
    });
  }
  let scheduled = false;
  const observer = new MutationObserver(() => { if (!scheduled) { scheduled = true; requestAnimationFrame(() => {scheduled = false; mount();}); } });
  document.addEventListener('DOMContentLoaded', () => { observer.observe(document.body, {childList: true, subtree: true}); mount(); });
  window.addEventListener('beforeprint', () => charts.forEach(chart => chart.resize()));
  window.addEventListener('afterprint', () => charts.forEach(chart => chart.resize()));
  return {markup};
})();
