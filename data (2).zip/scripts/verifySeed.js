const fs = require('node:fs');
const path = require('node:path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const ACC_ID = '53739463-e3fc-476a-8c45-a290fd89e72f';

const accounts = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'accounts.json'), 'utf8'));
const surveys = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'surveys.json'), 'utf8')).filter(s => s.accountId === ACC_ID);
const reports = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'reports.json'), 'utf8')).filter(r => r.accountId === ACC_ID);
const responses = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'responses.json'), 'utf8')).filter(r => r.accountId === ACC_ID);
const invitations = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'invitations.json'), 'utf8')).filter(i => i.accountId === ACC_ID);
const management = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'management.json'), 'utf8')).find(m => m.id === ACC_ID);

const { compareReports } = require('../src/domain/analysis');
const entitlementService = require('../src/services/entitlementService');

console.log('=== VERIFICAÇÃO DOS DADOS SEEDADOS ===');
console.log('Empresa:', accounts.find(a => a.id === ACC_ID).company);
console.log('Usuários da organização:', accounts.filter(a => a.id === ACC_ID || a.organizationId === ACC_ID).map(a => `${a.name} (${a.role})`));

console.log('\nPesquisas cadastradas (' + surveys.length + '):');
surveys.forEach(s => {
  const respCount = responses.filter(r => r.surveyId === s.id).length;
  const invTotal = invitations.filter(i => i.surveyId === s.id).length;
  const invUsed = invitations.filter(i => i.surveyId === s.id && i.usedAt).length;
  const pct = invTotal > 0 ? Math.round((respCount / invTotal) * 100) : 0;
  console.log(`- [${s.status.toUpperCase()}] "${s.title}" (${s.cycle}): ${respCount} respostas (${pct}% adesão), ${invUsed}/${invTotal} convites`);
});

console.log('\nRelatórios Publicados (' + reports.length + '):');
reports.forEach(r => {
  const demAvg = r.result.find(x => x.key === 'demandas')?.average;
  const jorAvg = r.result.find(x => x.key === 'jornada')?.average;
  const recAvg = r.result.find(x => x.key === 'reconhecimento')?.average;
  console.log(`- "${r.title}" (${r.cycle}): ${r.responseCount} respostas | Demandas: ${demAvg}, Jornada: ${jorAvg}, Reconhecimento: ${recAvg}`);
});

console.log('\nComparação Histórica (Junho 2026 vs 4º Trimestre 2025):');
const comp = compareReports(reports[1], reports[0]);
console.log('Comparável:', comp.comparable);
if (comp.comparable) {
  comp.factors.forEach(f => {
    const sign = f.delta >= 0 ? '+' : '';
    console.log(`  ${f.label}: ${f.previous} -> ${f.average} (delta: ${sign}${f.delta})`);
  });
}

console.log('\nMódulo de Gestão (NR-1):');
console.log('- Avaliações de risco:', management.assessments.length, 'itens:');
management.assessments.forEach(a => console.log(`  * [${a.status.toUpperCase()} | Prioridade: ${a.classification.toUpperCase()}] ${a.title}`));
console.log('- Planos de Ação:', management.actions.length, 'itens:');
management.actions.forEach(a => console.log(`  * [${a.status.toUpperCase()} | Prioridade: ${a.priority.toUpperCase()}] ${a.title} (Resp: ${a.owner})`));
console.log('- Auditoria (Trilha hash SHA-256):', management.audit.length, 'eventos encadeados');
console.log('- Assinatura:', entitlementService.entitlement(ACC_ID));

console.log('\n=== TUDO VALIDADO E PRONTO COM SUCESSO! ===');
