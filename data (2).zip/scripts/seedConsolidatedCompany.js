const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const { snapshotInstrument } = require('../src/domain/instruments');
const { aggregate, summarizeDistribution, compareReports } = require('../src/domain/analysis');
const passwordService = require('../src/services/passwordService');
const plans = require('../src/config/plans');

const DATA_DIR = path.join(__dirname, '..', 'data');
const ACC_ID = '53739463-e3fc-476a-8c45-a290fd89e72f';

function hash(val) {
  return crypto.createHash('sha256').update(val).digest('hex');
}
function uuid() {
  return crypto.randomUUID();
}

function loadJson(name) {
  return JSON.parse(fs.readFileSync(path.join(DATA_DIR, `${name}.json`), 'utf8'));
}

function saveJson(name, data) {
  fs.writeFileSync(path.join(DATA_DIR, `${name}.json`), JSON.stringify(data, null, 2) + '\n', 'utf8');
}

// Generates integer responses (1-5) matching a desired distribution profile
// Ensures every bucket (1..5) has at least 5 counts so summarizeDistribution is not suppressed.
function generateAnswers(count, profile) {
  const FACTORS = [
    'demandas',
    'autonomia',
    'apoio',
    'relacoes',
    'reconhecimento',
    'jornada',
    'mudancas',
    'seguranca'
  ];

  // Pre-seed 5 of each score (1..5) for each factor to guarantee unsuppressed distributions
  // That takes 25 slots if count >= 25, or if count < 25, we use realistic weights
  const results = [];
  for (let i = 0; i < count; i++) {
    results.push({});
  }

  FACTORS.forEach(f => {
    const weights = profile[f] || [0.1, 0.15, 0.25, 0.35, 0.15]; // weights for 1,2,3,4,5
    // Normalize weights
    const sumW = weights.reduce((a, b) => a + b, 0);
    const norm = weights.map(w => w / sumW);

    if (count >= 25) {
      // First assign 5 of each score (1,2,3,4,5) across the first 25 respondents
      const baseline = [
        1,1,1,1,1,
        2,2,2,2,2,
        3,3,3,3,3,
        4,4,4,4,4,
        5,5,5,5,5
      ];
      // Shuffle baseline
      baseline.sort(() => Math.random() - 0.5);
      for (let i = 0; i < 25; i++) {
        results[i][f] = baseline[i];
      }
      // Fill the remaining count - 25 with weighted distribution
      for (let i = 25; i < count; i++) {
        const rand = Math.random();
        let cumulative = 0;
        let chosen = 3;
        for (let s = 0; s < 5; s++) {
          cumulative += norm[s];
          if (rand <= cumulative) {
            chosen = s + 1;
            break;
          }
        }
        results[i][f] = chosen;
      }
    } else {
      // For smaller counts, just sample according to weights
      for (let i = 0; i < count; i++) {
        const rand = Math.random();
        let cumulative = 0;
        let chosen = 3;
        for (let s = 0; s < 5; s++) {
          cumulative += norm[s];
          if (rand <= cumulative) {
            chosen = s + 1;
            break;
          }
        }
        results[i][f] = chosen;
      }
    }
  });

  // Shuffle respondent answer objects
  results.sort(() => Math.random() - 0.5);
  return results;
}

function runSeed() {
  console.log('--- Starting Consolidated Company Seed ---');

  // Load existing datasets
  const accounts = loadJson('accounts');
  const members = loadJson('members');
  const groups = loadJson('groups');
  const surveys = loadJson('surveys');
  const responses = loadJson('responses');
  const invitations = loadJson('invitations');
  const reports = loadJson('reports');
  const management = loadJson('management');

  // 1. UPDATE ACCOUNTS
  const userAcc = accounts.find(a => a.id === ACC_ID);
  if (!userAcc) throw new Error('Account ' + ACC_ID + ' not found!');

  userAcc.company = 'Zenai Soluções Tecnológicas';
  userAcc.name = 'Nycolas';
  userAcc.createdAt = '2025-06-15T09:00:00.000Z';

  // Add 2 team members linked to this organization
  const otherAccounts = accounts.filter(a => a.id !== ACC_ID && a.organizationId !== ACC_ID);

  const teamMember1 = {
    id: 'user-mariana-rh-zenai',
    organizationId: ACC_ID,
    name: 'Mariana Costa (Coord. RH)',
    company: 'Zenai Soluções Tecnológicas',
    email: 'mariana.costa@zenai.com.br',
    role: 'editor',
    passwordHash: passwordService.derive('Equilibra2026!'),
    createdAt: '2025-08-20T10:00:00.000Z'
  };

  const teamMember2 = {
    id: 'user-carlos-sst-zenai',
    organizationId: ACC_ID,
    name: 'Dr. Carlos Eduardo (SST)',
    company: 'Zenai Soluções Tecnológicas',
    email: 'carlos.eduardo@zenai.com.br',
    role: 'viewer',
    passwordHash: passwordService.derive('Equilibra2026!'),
    createdAt: '2025-09-01T14:30:00.000Z'
  };

  const updatedAccounts = [...otherAccounts, userAcc, teamMember1, teamMember2];

  // 2. CHECK GROUPS & MEMBERS
  const userGroups = groups.filter(g => g.accountId === ACC_ID);
  const generalGroup = userGroups.find(g => g.name.toLowerCase() === 'geral');
  const tecGroup = userGroups.find(g => g.name.toLowerCase() === 'tecnologia');
  const opGroup = userGroups.find(g => g.name.toLowerCase() === 'operações');
  const logGroup = userGroups.find(g => g.name.toLowerCase() === 'logística');
  const comGroup = userGroups.find(g => g.name.toLowerCase() === 'comercial');
  const ateGroup = userGroups.find(g => g.name.toLowerCase() === 'atendimento');
  const rhGroup = userGroups.find(g => g.name.toLowerCase() === 'recursos humanos');
  const finGroup = userGroups.find(g => g.name.toLowerCase() === 'financeiro');
  const mktGroup = userGroups.find(g => g.name.toLowerCase() === 'marketing');

  if (!generalGroup || !tecGroup || !opGroup || !logGroup || !comGroup || !ateGroup || !rhGroup || !finGroup || !mktGroup) {
    throw new Error('Expected default department groups not found!');
  }

  const allUserMembers = members.filter(m => m.accountId === ACC_ID);
  console.log(`Found ${allUserMembers.length} members for account.`);

  // 3. DEFINE SURVEYS
  // Instrument for Exploratory Diagnostico inicial
  const defaultInstrument = snapshotInstrument('Diagnóstico inicial');

  // Closed Survey 1: Diagnóstico Institucional 2025 (Geral, 203 members)
  const survey1Id = 'c1c10001-2025-4a01-8001-zenai0000001';
  const survey1Members = [...generalGroup.memberIds];
  const survey1Fingerprint = hash([...survey1Members].sort().join(':'));

  // Closed Survey 2: Pulso Geral Meio de Ano 2026 (Geral, 203 members)
  const survey2Id = 'c1c10002-2026-4a02-8002-zenai0000002';
  const survey2Members = [...generalGroup.memberIds];
  const survey2Fingerprint = hash([...survey2Members].sort().join(':')); // Identical fingerprint!

  // Closed Survey 3: Escuta Focada RH & Financeiro (44 members)
  const survey3Id = 'c1c10003-2026-4a03-8003-zenai0000003';
  const survey3Members = [...new Set([...rhGroup.memberIds, ...finGroup.memberIds])];
  const survey3Fingerprint = hash([...survey3Members].sort().join(':'));

  // Closed Survey 4: Avaliação de Pico de Campanha - Marketing (22 members)
  const survey4Id = 'c1c10004-2026-4a04-8004-zenai0000004';
  const survey4Members = [...mktGroup.memberIds];
  const survey4Fingerprint = hash([...survey4Members].sort().join(':'));

  // Open Survey 5: Pulso Focado: Carga de Trabalho & Prazos - Tecnologia (26 members)
  const survey5Id = 'c1c10005-2026-4a05-8005-zenai0000005';
  const survey5Members = [...tecGroup.memberIds];
  const survey5Fingerprint = hash([...survey5Members].sort().join(':'));

  // Open Survey 6: Monitoramento de Rotinas e Segurança - Operações & Logística (45 members)
  const survey6Id = 'c1c10006-2026-4a06-8006-zenai0000006';
  const survey6Members = [...new Set([...opGroup.memberIds, ...logGroup.memberIds])];
  const survey6Fingerprint = hash([...survey6Members].sort().join(':'));

  // Open Survey 7: Campanha Q4: Percepção de Suporte e Metas - Comercial & Atendimento (44 members)
  const survey7Id = 'c1c10007-2026-4a07-8007-zenai0000007';
  const survey7Members = [...new Set([...comGroup.memberIds, ...ateGroup.memberIds])];
  const survey7Fingerprint = hash([...survey7Members].sort().join(':'));

  // Draft Survey 8: Planejamento Geral 2027 (Geral)
  const survey8Id = 'c1c10008-2026-4a08-8008-zenai0000008';
  const survey8Members = [...generalGroup.memberIds];

  const newSurveys = [
    {
      id: survey1Id,
      accountId: ACC_ID,
      title: 'Diagnóstico Institucional de Fatores Psicossociais 2025',
      cycle: '4º trimestre de 2025',
      model: 'Diagnóstico inicial',
      groupIds: [generalGroup.id],
      groupId: generalGroup.id,
      memberIds: survey1Members,
      endsAt: '2025-11-28T23:59:59.000Z',
      status: 'closed',
      createdAt: '2025-10-15T09:00:00.000Z',
      openedAt: '2025-10-15T09:30:00.000Z',
      closedAt: '2025-11-28T18:00:00.000Z',
      instrument: defaultInstrument,
      collectionChannel: 'web',
      audienceFingerprint: survey1Fingerprint,
      groupNamesSnapshot: ['Geral']
    },
    {
      id: survey2Id,
      accountId: ACC_ID,
      title: 'Pulso Geral de Acompanhamento - Meio de Ano 2026',
      cycle: 'junho de 2026',
      model: 'Diagnóstico inicial',
      groupIds: [generalGroup.id],
      groupId: generalGroup.id,
      memberIds: survey2Members,
      endsAt: '2026-06-30T23:59:59.000Z',
      status: 'closed',
      createdAt: '2026-06-01T09:00:00.000Z',
      openedAt: '2026-06-01T09:15:00.000Z',
      closedAt: '2026-06-29T18:30:00.000Z',
      instrument: defaultInstrument,
      collectionChannel: 'web',
      audienceFingerprint: survey2Fingerprint,
      groupNamesSnapshot: ['Geral']
    },
    {
      id: survey3Id,
      accountId: ACC_ID,
      title: 'Escuta Focada em Clima e Integração - RH & Financeiro',
      cycle: 'agosto de 2026',
      model: 'Escuta focada',
      groupIds: [rhGroup.id, finGroup.id],
      groupId: rhGroup.id,
      memberIds: survey3Members,
      endsAt: '2026-08-30T23:59:59.000Z',
      status: 'closed',
      createdAt: '2026-08-05T09:00:00.000Z',
      openedAt: '2026-08-05T09:30:00.000Z',
      closedAt: '2026-08-28T17:00:00.000Z',
      instrument: snapshotInstrument('Escuta focada'),
      collectionChannel: 'web',
      audienceFingerprint: survey3Fingerprint,
      groupNamesSnapshot: ['Recursos Humanos', 'Financeiro']
    },
    {
      id: survey4Id,
      accountId: ACC_ID,
      title: 'Avaliação de Ritmo de Campanha - Marketing',
      cycle: 'setembro de 2026',
      model: 'Evento: pico ou pressão',
      groupIds: [mktGroup.id],
      groupId: mktGroup.id,
      memberIds: survey4Members,
      endsAt: '2026-09-25T23:59:59.000Z',
      status: 'closed',
      createdAt: '2026-09-01T10:00:00.000Z',
      openedAt: '2026-09-01T10:15:00.000Z',
      closedAt: '2026-09-24T18:00:00.000Z',
      instrument: snapshotInstrument('Evento: pico ou pressão'),
      collectionChannel: 'web',
      audienceFingerprint: survey4Fingerprint,
      groupNamesSnapshot: ['Marketing']
    },
    {
      id: survey5Id,
      accountId: ACC_ID,
      title: 'Pulso Focado: Carga de Trabalho & Prazos - Tecnologia',
      cycle: 'outubro de 2026',
      model: 'Escuta focada',
      groupIds: [tecGroup.id],
      groupId: tecGroup.id,
      memberIds: survey5Members,
      endsAt: '2026-11-15T23:59:59.000Z',
      status: 'open',
      createdAt: '2026-10-12T08:30:00.000Z',
      openedAt: '2026-10-12T09:00:00.000Z',
      closedAt: null,
      instrument: snapshotInstrument('Escuta focada'),
      collectionChannel: 'web',
      audienceFingerprint: survey5Fingerprint,
      groupNamesSnapshot: ['Tecnologia']
    },
    {
      id: survey6Id,
      accountId: ACC_ID,
      title: 'Monitoramento de Rotinas e Segurança Operacional - Operações & Logística',
      cycle: 'outubro de 2026',
      model: 'Pulso mensal',
      groupIds: [opGroup.id, logGroup.id],
      groupId: opGroup.id,
      memberIds: survey6Members,
      endsAt: '2026-11-20T23:59:59.000Z',
      status: 'open',
      createdAt: '2026-10-14T09:00:00.000Z',
      openedAt: '2026-10-14T09:30:00.000Z',
      closedAt: null,
      instrument: snapshotInstrument('Pulso mensal'),
      collectionChannel: 'web',
      audienceFingerprint: survey6Fingerprint,
      groupNamesSnapshot: ['Operações', 'Logística']
    },
    {
      id: survey7Id,
      accountId: ACC_ID,
      title: 'Campanha Q4: Percepção de Suporte e Metas - Comercial & Atendimento',
      cycle: 'outubro de 2026',
      model: 'Diagnóstico inicial',
      groupIds: [comGroup.id, ateGroup.id],
      groupId: comGroup.id,
      memberIds: survey7Members,
      endsAt: '2026-11-25T23:59:59.000Z',
      status: 'open',
      createdAt: '2026-10-16T10:00:00.000Z',
      openedAt: '2026-10-16T10:30:00.000Z',
      closedAt: null,
      instrument: defaultInstrument,
      collectionChannel: 'web',
      audienceFingerprint: survey7Fingerprint,
      groupNamesSnapshot: ['Comercial', 'Atendimento']
    },
    {
      id: survey8Id,
      accountId: ACC_ID,
      title: 'Diagnóstico Anual Geral de Percepção do Trabalho 2027',
      cycle: 'janeiro de 2027',
      model: 'Diagnóstico inicial',
      groupIds: [generalGroup.id],
      groupId: generalGroup.id,
      memberIds: survey8Members,
      endsAt: '2027-02-28T23:59:59.000Z',
      status: 'draft',
      createdAt: '2026-10-18T14:00:00.000Z',
      openedAt: null,
      closedAt: null,
      instrument: defaultInstrument,
      collectionChannel: 'web',
      audienceFingerprint: null,
      groupNamesSnapshot: ['Geral']
    }
  ];

  // Keep other accounts' surveys
  const preservedSurveys = surveys.filter(s => s.accountId !== ACC_ID);

  // 4. GENERATE RESPONSES AND INVITATIONS
  const otherResponses = responses.filter(r => r.accountId !== ACC_ID);
  const otherInvitations = invitations.filter(i => i.accountId !== ACC_ID);

  const newResponses = [];
  const newInvitations = [];

  // Helper to generate survey responses & invitations
  function setupSurveyData(survey, respondentCount, profile) {
    const rawAnswers = generateAnswers(respondentCount, profile);
    const memberPool = [...survey.memberIds];
    // Shuffle members
    memberPool.sort(() => Math.random() - 0.5);

    const respondingMemberIds = new Set(memberPool.slice(0, respondentCount));

    survey.memberIds.forEach(mId => {
      const isResponder = respondingMemberIds.has(mId);
      const token = crypto.randomBytes(24).toString('hex');
      const tokenHash = hash(token);

      newInvitations.push({
        id: uuid(),
        accountId: ACC_ID,
        surveyId: survey.id,
        memberId: mId,
        tokenHash,
        usedAt: isResponder ? (survey.closedAt || '2026-10-18T12:00:00.000Z') : null
      });
    });

    for (let i = 0; i < respondentCount; i++) {
      const respId = uuid();
      newResponses.push({
        id: respId,
        accountId: ACC_ID,
        surveyId: survey.id,
        answers: rawAnswers[i]
      });
    }

    return newResponses.filter(r => r.surveyId === survey.id);
  }

  // Survey 1: Q4 2025 - Initial baseline, lower scores in demandas (overload) and jornada
  const s1Profile = {
    demandas: [0.35, 0.30, 0.20, 0.10, 0.05], // avg ~2.2
    autonomia: [0.05, 0.15, 0.25, 0.35, 0.20], // avg ~3.5
    apoio: [0.10, 0.20, 0.30, 0.25, 0.15], // avg ~3.15
    relacoes: [0.05, 0.10, 0.25, 0.40, 0.20], // avg ~3.6
    reconhecimento: [0.25, 0.30, 0.25, 0.15, 0.05], // avg ~2.45
    jornada: [0.30, 0.30, 0.20, 0.15, 0.05], // avg ~2.35
    mudancas: [0.15, 0.25, 0.30, 0.20, 0.10], // avg ~2.85
    seguranca: [0.05, 0.10, 0.25, 0.35, 0.25] // avg ~3.65
  };
  const s1Responses = setupSurveyData(newSurveys[0], 172, s1Profile);

  // Survey 2: Junho 2026 - Noticeable improvements across all factors due to implemented actions!
  const s2Profile = {
    demandas: [0.05, 0.10, 0.30, 0.35, 0.20], // avg ~3.55 (+1.35 improvement)
    autonomia: [0.05, 0.08, 0.20, 0.42, 0.25], // avg ~3.74
    apoio: [0.05, 0.08, 0.22, 0.40, 0.25], // avg ~3.72
    relacoes: [0.03, 0.05, 0.18, 0.44, 0.30], // avg ~3.93
    reconhecimento: [0.08, 0.12, 0.30, 0.32, 0.18], // avg ~3.40
    jornada: [0.08, 0.12, 0.28, 0.34, 0.18], // avg ~3.42
    mudancas: [0.06, 0.10, 0.26, 0.38, 0.20], // avg ~3.56
    seguranca: [0.03, 0.05, 0.15, 0.45, 0.32] // avg ~3.98
  };
  const s2Responses = setupSurveyData(newSurveys[1], 181, s2Profile);

  // Survey 3: Agosto 2026 (RH & Financeiro - 44 members, 39 responses)
  const s3Profile = {
    demandas: [0.05, 0.10, 0.30, 0.40, 0.15],
    autonomia: [0.05, 0.05, 0.20, 0.45, 0.25],
    apoio: [0.05, 0.05, 0.20, 0.45, 0.25],
    relacoes: [0.02, 0.05, 0.15, 0.48, 0.30],
    reconhecimento: [0.05, 0.10, 0.30, 0.35, 0.20],
    jornada: [0.05, 0.10, 0.25, 0.40, 0.20],
    mudancas: [0.05, 0.10, 0.25, 0.40, 0.20],
    seguranca: [0.02, 0.05, 0.15, 0.48, 0.30]
  };
  const s3Responses = setupSurveyData(newSurveys[2], 39, s3Profile);

  // Survey 4: Setembro 2026 (Marketing - 22 members, 20 responses)
  const s4Profile = {
    demandas: [0.10, 0.20, 0.30, 0.25, 0.15],
    autonomia: [0.05, 0.05, 0.20, 0.40, 0.30],
    apoio: [0.05, 0.10, 0.25, 0.40, 0.20],
    relacoes: [0.05, 0.05, 0.20, 0.45, 0.25],
    reconhecimento: [0.05, 0.10, 0.25, 0.40, 0.20],
    jornada: [0.10, 0.15, 0.30, 0.30, 0.15],
    mudancas: [0.05, 0.10, 0.25, 0.40, 0.20],
    seguranca: [0.05, 0.05, 0.20, 0.45, 0.25]
  };
  const s4Responses = setupSurveyData(newSurveys[3], 20, s4Profile);

  // Open Survey 5: Tecnologia (26 members, 18 responses so far)
  const s5Responses = setupSurveyData(newSurveys[4], 18, s2Profile);

  // Open Survey 6: Operações & Logística (45 members, 29 responses so far)
  const s6Responses = setupSurveyData(newSurveys[5], 29, s2Profile);

  // Open Survey 7: Comercial & Atendimento (44 members, 27 responses so far)
  const s7Responses = setupSurveyData(newSurveys[6], 27, s2Profile);

  // Draft Survey 8: (0 responses)
  setupSurveyData(newSurveys[7], 0, s2Profile);

  // 5. COMPUTE REPORTS FOR CLOSED SURVEYS
  const otherReports = reports.filter(r => r.accountId !== ACC_ID);
  const newReports = [];

  const closedSurveys = [newSurveys[0], newSurveys[1], newSurveys[2], newSurveys[3]];
  const closedResponses = [s1Responses, s2Responses, s3Responses, s4Responses];

  closedSurveys.forEach((survey, idx) => {
    const resps = closedResponses[idx];
    const result = aggregate(resps, defaultInstrument);
    const distribution = summarizeDistribution(resps, defaultInstrument);

    // Save result on the survey object as well
    survey.result = result;
    survey.responseCount = resps.length;

    const repId = `rep-zenai-000${idx + 1}-${survey.id.slice(-8)}`;

    newReports.push({
      id: repId,
      accountId: ACC_ID,
      surveyId: survey.id,
      title: survey.title,
      cycle: survey.cycle,
      model: survey.model,
      groupName: survey.groupNamesSnapshot.join(', '),
      closedAt: survey.closedAt,
      published: true,
      responseCount: resps.length,
      result,
      suppressionReason: null,
      instrument: survey.instrument,
      audienceFingerprint: survey.audienceFingerprint,
      groupNames: survey.groupNamesSnapshot,
      distribution,
      methodology: `${defaultInstrument.name}, versão ${defaultInstrument.version}; ${defaultInstrument.factors.length} afirmações; ${defaultInstrument.limitation}`,
      collectionChannel: 'web'
    });
  });

  // Verify compareReports between Survey 2 (current) and Survey 1 (previous)
  const comp = compareReports(newReports[1], newReports[0]);
  console.log('compareReports result:', {
    comparable: comp.comparable,
    reason: comp.reason,
    factorsCount: comp.factors?.length
  });
  if (!comp.comparable) {
    console.warn('WARNING: comparison not comparable:', comp.reason);
  }

  // 6. CONFIGURE MANAGEMENT.JSON (NR-1 Risk Management, Assessments, Actions, Audit, Subscriptions)
  const otherManagement = management.filter(m => m.id !== ACC_ID);

  const report1 = newReports[0];
  const report2 = newReports[1];
  const report4 = newReports[3];

  const assessment1Id = 'asm-zenai-001-demandas';
  const assessment2Id = 'asm-zenai-002-jornada';
  const assessment3Id = 'asm-zenai-003-reconhecimento';
  const assessment4Id = 'asm-zenai-004-mudancas';

  const action1Id = 'act-zenai-001-triagem';
  const action2Id = 'act-zenai-002-desconexao';
  const action3Id = 'act-zenai-003-lideranca';
  const action4Id = 'act-zenai-004-feedback';

  const assessments = [
    {
      id: assessment1Id,
      reportId: report1.id,
      factor: 'demandas',
      title: 'Sobrecarga de demandas e acúmulo de tarefas em períodos de entrega',
      context: 'Média de 2.2 no ciclo institucional 2025 apontou ritmo acelerado e sobrecarga recorrente nos fechamentos operacionais.',
      existingMeasures: 'Plantões de suporte escalonados e banco de horas informal.',
      decision: 'Estruturação de plano imediato para automação de triagem, contratação de novos analistas e redimensionamento de SLAs.',
      status: 'evaluated',
      classification: 'high',
      version: 1,
      createdAt: '2025-12-05T10:00:00.000Z',
      updatedAt: '2025-12-05T10:00:00.000Z'
    },
    {
      id: assessment2Id,
      reportId: report1.id,
      factor: 'jornada',
      title: 'Dificuldade na desconexão digital fora do expediente de trabalho',
      context: 'Identificado índice crítico de 2.35 em jornada. Colaboradores relataram mensagens fora do expediente e interrupções frequentes.',
      existingMeasures: 'Orientação verbal para não responder após o expediente.',
      decision: 'Instituir e homologar formalmente a Política Institucional de Desconexão e Pausas Ativas.',
      status: 'evaluated',
      classification: 'medium',
      version: 1,
      createdAt: '2025-12-08T14:00:00.000Z',
      updatedAt: '2025-12-08T14:00:00.000Z'
    },
    {
      id: assessment3Id,
      reportId: report2.id,
      factor: 'reconhecimento',
      title: 'Aprimoramento do programa de reconhecimento e progressão profissional',
      context: 'Após os avanços registrados no ciclo de junho/2026, consolidar a estrutura de valorização das equipes e critérios transparentes de promoção.',
      existingMeasures: 'Feedbacks pontuais e reuniões de alinhamento com líderes.',
      decision: 'Implantar comitê de cultura e programa estruturado de feedbacks 1:1 e plano de desenvolvimento individual.',
      status: 'evaluated',
      classification: 'low',
      version: 1,
      createdAt: '2026-07-10T11:00:00.000Z',
      updatedAt: '2026-07-10T11:00:00.000Z'
    },
    {
      id: assessment4Id,
      reportId: report4.id,
      factor: 'mudancas',
      title: 'Comunicação antecipada de transições de processos no Marketing',
      context: 'Investigação em andamento sobre o nível de antecedência no comunicado de novas campanhas.',
      existingMeasures: 'E-mails e informativos da liderança.',
      decision: '',
      status: 'investigating',
      classification: 'medium',
      version: 1,
      createdAt: '2026-09-28T16:00:00.000Z',
      updatedAt: '2026-09-28T16:00:00.000Z'
    }
  ];

  const actions = [
    {
      id: action1Id,
      assessmentId: assessment1Id,
      title: 'Implantação de sistema de triagem automática e expansão do time de atendimento',
      description: 'Reestruturação do fluxo de chamados operacionais, automação de triagens repetitivas e admissão de 4 novos analistas para absorver a expansão da empresa.',
      owner: 'Mariana Costa (Coord. RH / Operações)',
      dueDate: '2026-04-15',
      reviewDate: '2026-05-30',
      successCriteria: 'Redução de 30% nas horas extras e elevação da percepção de demandas para nota superior a 3.3.',
      priority: 'high',
      status: 'effective',
      review: 'Eficácia comprovada. Média do fator Demandas subiu para 3.55 no ciclo de Junho/2026, com redução comprovada de horas extras e satisfação da equipe.',
      evidence: [
        {
          id: 'evi-zenai-001',
          createdAt: '2026-04-14T15:30:00.000Z',
          title: 'Relatório de admissão dos 4 analistas e homologação do software de triagem',
          description: 'Documentação de admissão no portal de RH e relatório técnico do software em produção.',
          url: 'https://zenai.intranet/docs/relatorio-triagem-2026.pdf',
          recordedBy: 'Mariana Costa'
        }
      ],
      version: 2,
      createdAt: '2025-12-10T09:00:00.000Z',
      updatedAt: '2026-05-30T17:00:00.000Z'
    },
    {
      id: action2Id,
      assessmentId: assessment2Id,
      title: 'Cartilha e Diretriz Corporativa de Direito à Desconexão e Pausas Ativas',
      description: 'Formalização de regras de não envio de comunicações fora da jornada, suspensão de notificações em aplicativos corporativos e campanhas de pausas ergonômicas.',
      owner: 'Nycolas / Diretoria de Pessoas',
      dueDate: '2026-07-15',
      reviewDate: '2026-08-30',
      successCriteria: 'Média de jornada e descanso superior a 3.4 em todos os setores no ciclo subsequente.',
      priority: 'medium',
      status: 'effective',
      review: 'Diretriz aprovada pela CIPA e adotada em 100% dos departamentos. Nota de jornada evoluiu para 3.42 com adesão positiva dos colaboradores.',
      evidence: [
        {
          id: 'evi-zenai-002',
          createdAt: '2026-07-12T11:00:00.000Z',
          title: 'Ata de aprovação da Diretriz de Desconexão assinada pela CIPA e Diretoria',
          description: 'Campanha de divulgação concluída e termo de ciência assinado pelas lideranças.',
          url: 'https://zenai.intranet/docs/politica-desconexao-cipa.pdf',
          recordedBy: 'Nycolas'
        }
      ],
      version: 2,
      createdAt: '2025-12-12T10:00:00.000Z',
      updatedAt: '2026-08-30T16:30:00.000Z'
    },
    {
      id: action3Id,
      assessmentId: assessment1Id,
      title: 'Programa de Capacitação de Lideranças em Gestão de Prazos e Prevenção de Estresse',
      description: 'Oficinas práticas ministradas pelo time de SST para coordenadores e gestores de tecnologia e operações sobre dimensionamento saudável de demandas.',
      owner: 'Dr. Carlos Eduardo (SST)',
      dueDate: '2026-11-20',
      reviewDate: '2026-12-15',
      successCriteria: '100% dos líderes de squad capacitados com frequência registrada.',
      priority: 'high',
      status: 'in_progress',
      review: '',
      evidence: [],
      version: 1,
      createdAt: '2026-08-15T14:00:00.000Z',
      updatedAt: '2026-08-15T14:00:00.000Z'
    },
    {
      id: action4Id,
      assessmentId: assessment3Id,
      title: 'Implantação do Ciclo de Feedbacks 1:1 e Guia de Desenvolvimento Profissional',
      description: 'Padronização da rotina quinzenal de alinhamento individual entre líderes e liderados, com foco em reconhecimento e plano de evolução técnica.',
      owner: 'Mariana Costa (Coord. RH)',
      dueDate: '2026-12-05',
      reviewDate: '2027-01-20',
      successCriteria: 'Adesão mínima de 90% dos times às rodadas mensais de 1:1.',
      priority: 'medium',
      status: 'planned',
      review: '',
      evidence: [],
      version: 1,
      createdAt: '2026-07-20T09:30:00.000Z',
      updatedAt: '2026-07-20T09:30:00.000Z'
    }
  ];

  // AI Assistant History showing AI generation of action plans
  const aiHistory = [
    {
      id: 'ai-zenai-hist-001',
      createdAt: '2025-12-09T14:20:00.000Z',
      reportId: report1.id,
      question: 'Quais medidas organizacionais são recomendadas para tratar sobrecarga de demandas em períodos de fechamento?',
      explanation: 'Com base nos resultados coletivos do ciclo 2025, o fator Demandas apresentou média de 2.20, sugerindo descompasso sazonal entre o volume de trabalho e o dimensionamento da equipe. Recomenda-se investigar a distribuição de tarefas nos períodos críticos, automatizar processos manuais repetitivos e rever os prazos operacionais antes de recorrer a soluções punitivas ou individuais.',
      suggestion: {
        title: 'Redimensionamento de carga de trabalho e automação de triagem em períodos de pico',
        description: 'Revisar fluxo de processos operacionais e implementar mecanismos automáticos de triagem para diminuir o acúmulo de tarefas.',
        successCriteria: 'Elevação da pontuação média do fator Demandas para patamar satisfatório (> 3.3) na avaliação do ciclo subsequente.',
        rationale: 'Fatores organizacionais respondem de forma mais sustentável a mudanças estruturais no desenho do trabalho do que a intervenções comportamentais isoladas.'
      }
    }
  ];

  // Active advanced plan subscription
  const advancedPlan = plans.find(p => p.id === 'avancado') || {
    id: 'avancado',
    name: 'Avançado',
    amountCents: 79900,
    members: 600,
    groups: 40,
    users: 12,
    organizations: 1,
    aiMonthly: 200
  };

  const subscriptions = [
    {
      id: 'sub-zenai-avancado-2026',
      providerId: 'preapproval_zenai_corp_2026',
      status: 'authorized',
      plan: advancedPlan,
      paidUntil: '2027-10-31T23:59:59.000Z',
      createdAt: '2025-08-15T10:00:00.000Z'
    }
  ];

  // Chained Audit log with cryptographic hash verification
  const audit = [];
  function addAuditEvent(event, entityId, actorName, actorId, before, after, timestamp) {
    const entry = {
      id: uuid(),
      at: timestamp || new Date().toISOString(),
      actorId: actorId || ACC_ID,
      actor: actorName || 'Nycolas',
      event,
      entityId,
      previousHash: audit.length > 0 ? audit[audit.length - 1].hash : null
    };
    if (before !== undefined) entry.before = before;
    if (after !== undefined) entry.after = after;
    entry.hash = crypto.createHash('sha256').update(JSON.stringify(entry)).digest('hex');
    audit.push(entry);
  }

  addAuditEvent('workspace.created', ACC_ID, 'Sistema', 'system', null, null, '2025-06-15T09:00:00.000Z');
  addAuditEvent('billing.subscription_activated', subscriptions[0].id, 'Mercado Pago', 'system', null, null, '2025-08-15T10:00:00.000Z');
  addAuditEvent('team.member_added', teamMember1.id, 'Nycolas', ACC_ID, null, { email: teamMember1.email, role: 'editor' }, '2025-08-20T10:00:00.000Z');
  addAuditEvent('team.member_added', teamMember2.id, 'Nycolas', ACC_ID, null, { email: teamMember2.email, role: 'viewer' }, '2025-09-01T14:30:00.000Z');
  addAuditEvent('assessment.created', assessment1Id, 'Mariana Costa', teamMember1.id, null, assessments[0], '2025-12-05T10:00:00.000Z');
  addAuditEvent('assessment.created', assessment2Id, 'Nycolas', ACC_ID, null, assessments[1], '2025-12-08T14:00:00.000Z');
  addAuditEvent('action.created', action1Id, 'Mariana Costa', teamMember1.id, null, actions[0], '2025-12-10T09:00:00.000Z');
  addAuditEvent('action.created', action2Id, 'Nycolas', ACC_ID, null, actions[1], '2025-12-12T10:00:00.000Z');
  addAuditEvent('action.evidence_added', action1Id, 'Mariana Costa', teamMember1.id, null, actions[0].evidence[0], '2026-04-14T15:30:00.000Z');
  addAuditEvent('action.updated', action1Id, 'Mariana Costa', teamMember1.id, null, actions[0], '2026-05-30T17:00:00.000Z');
  addAuditEvent('action.evidence_added', action2Id, 'Nycolas', ACC_ID, null, actions[1].evidence[0], '2026-07-12T11:00:00.000Z');
  addAuditEvent('action.updated', action2Id, 'Nycolas', ACC_ID, null, actions[1], '2026-08-30T16:30:00.000Z');
  addAuditEvent('assessment.created', assessment3Id, 'Mariana Costa', teamMember1.id, null, assessments[2], '2026-07-10T11:00:00.000Z');
  addAuditEvent('action.created', action3Id, 'Dr. Carlos Eduardo', teamMember2.id, null, actions[2], '2026-08-15T14:00:00.000Z');
  addAuditEvent('action.created', action4Id, 'Mariana Costa', teamMember1.id, null, actions[3], '2026-07-20T09:30:00.000Z');
  addAuditEvent('assessment.created', assessment4Id, 'Mariana Costa', teamMember1.id, null, assessments[3], '2026-09-28T16:00:00.000Z');

  const userManagement = {
    id: ACC_ID,
    retentionMonths: 24,
    assessments,
    actions,
    audit,
    invitations: [],
    schedules: [],
    aiHistory,
    subscriptions,
    recovery: []
  };

  const updatedManagement = [...otherManagement, userManagement];

  // 7. WRITE EVERYTHING TO DATA FILES
  saveJson('accounts', updatedAccounts);
  saveJson('surveys', [...preservedSurveys, ...newSurveys]);
  saveJson('responses', [...otherResponses, ...newResponses]);
  saveJson('invitations', [...otherInvitations, ...newInvitations]);
  saveJson('reports', [...otherReports, ...newReports]);
  saveJson('management', updatedManagement);

  console.log('--- SEED COMPLETED SUCCESSFULLY! ---');
  console.log(`- Surveys: ${newSurveys.length} total (${closedSurveys.length} closed, 3 open, 1 draft)`);
  console.log(`- Responses: ${newResponses.length} total`);
  console.log(`- Invitations: ${newInvitations.length} total`);
  console.log(`- Reports: ${newReports.length} total`);
  console.log(`- Assessments: ${assessments.length} total`);
  console.log(`- Actions: ${actions.length} total`);
  console.log(`- Audit events: ${audit.length} total`);
}

runSeed();
